<?php
/**
 * Plugin Name: Kimiya Diagnostic Agent
 * Plugin URI: https://www.kimiazivar.com/
 * Description: Read-only diagnostics, expiring remote diagnostic sessions, fatal error capture, and signed self-updates for WordPress.
 * Version: 1.1.10
 * Author: Kimiya
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: kimiya-diagnostic-agent
 */

if (!defined('ABSPATH')) { exit; }

define('KDA_VERSION', '1.1.10');
define('KDA_FILE', __FILE__);
define('KDA_DIR', plugin_dir_path(__FILE__));
define('KDA_BASENAME', plugin_basename(__FILE__));
define('KDA_DEFAULT_PUBLIC_KEY', 'vI6AyQnzGPujr2Paj2M+SksDsi6WEj/8XwJlqA5DZgw=');
define('KDA_DEFAULT_MANIFEST_URL', 'https://raw.githubusercontent.com/kimiareza8-prog/NexaClean-Pro/kda-releases/kda/manifest.json');

require_once KDA_DIR . 'includes/class-kda-security.php';
require_once KDA_DIR . 'includes/class-kda-profiler.php';
require_once KDA_DIR . 'includes/class-kda-repair-inspector.php';
require_once KDA_DIR . 'includes/class-kda-agent-card.php';
require_once KDA_DIR . 'includes/class-kda-cache-inspector.php';
require_once KDA_DIR . 'includes/class-kda-repair.php';
require_once KDA_DIR . 'includes/class-kda-listing-optimizer.php';
require_once KDA_DIR . 'includes/class-kda-repair-admin.php';
require_once KDA_DIR . 'includes/class-kda-diagnostics.php';
require_once KDA_DIR . 'includes/class-kda-updater.php';
require_once KDA_DIR . 'includes/class-kda-admin.php';

KDA_Profiler::bootstrap();
KDA_Updater::maybe_migrate_settings();

final class Kimiya_Diagnostic_Agent {
    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        register_shutdown_function(array($this, 'capture_shutdown'));
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        add_action('kda_hourly_event', array('KDA_Updater', 'cron_run'));
        add_filter('plugin_action_links_' . KDA_BASENAME, array($this, 'action_links'));

        if (is_admin()) {
            KDA_Admin::init();
        }
    }

    public static function activate() {
        if (!get_option('kda_update_public_key')) {
            add_option('kda_update_public_key', KDA_DEFAULT_PUBLIC_KEY, '', false);
        }
        if (!get_option('kda_settings')) {
            add_option('kda_settings', array(
                'manifest_url' => KDA_DEFAULT_MANIFEST_URL,
                'auto_update'  => 1,
                'retain_errors' => 30,
            ), '', false);
        }
        if (!wp_next_scheduled('kda_hourly_event')) {
            wp_schedule_event(time() + 300, 'hourly', 'kda_hourly_event');
        }
    }

    public static function deactivate() {
        wp_clear_scheduled_hook('kda_hourly_event');
        delete_transient('kda_update_lock');
    }

    public function action_links($links) {
        array_unshift($links, '<a href="' . esc_url(admin_url('tools.php?page=kimiya-diagnostic-agent')) . '">Dashboard</a>');
        return $links;
    }

    public function capture_shutdown() {
        $error = error_get_last();
        if (!$error || !in_array((int)$error['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR), true)) {
            return;
        }
        KDA_Diagnostics::store_fatal($error);
    }

    public function register_rest_routes() {
        register_rest_route('kda/v1', '/agent', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'rest_agent'),
            'permission_callback' => array('KDA_Security', 'authorize_diagnostic_request'),
        ));

        register_rest_route('kda/v1', '/ping', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'rest_ping'),
            'permission_callback' => array('KDA_Security', 'authorize_diagnostic_request'),
        ));
        register_rest_route('kda/v1', '/report', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'rest_report'),
            'permission_callback' => array('KDA_Security', 'authorize_diagnostic_request'),
        ));
        register_rest_route('kda/v1', '/signed-report', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'rest_report'),
            'permission_callback' => array('KDA_Security', 'authorize_signed_report_request'),
        ));
        register_rest_route('kda/v1', '/signed-profile', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'rest_profile'),
            'permission_callback' => array('KDA_Security', 'authorize_signed_profile_request'),
        ));
        register_rest_route('kda/v1', '/signed-repair-inspect', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'rest_repair_inspect'),
            'permission_callback' => array('KDA_Security', 'authorize_signed_profile_request'),
        ));
        register_rest_route('kda/v1', '/signed-repair', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'rest_repair'),
            'permission_callback' => array('KDA_Security', 'authorize_signed_repair_request'),
        ));
        register_rest_route('kda/v1', '/errors', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'rest_errors'),
            'permission_callback' => array('KDA_Security', 'authorize_diagnostic_request'),
        ));
        register_rest_route('kda/v1', '/update-status', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'rest_update_status'),
            'permission_callback' => array('KDA_Security', 'authorize_diagnostic_request'),
        ));
        register_rest_route('kda/v1', '/update-trigger', array(
            'methods' => array(WP_REST_Server::READABLE, WP_REST_Server::CREATABLE),
            'callback' => array($this, 'rest_update_trigger'),
            'permission_callback' => array('KDA_Security', 'authorize_signed_update_trigger'),
        ));
    }

    private function no_store($data) {
        $response = rest_ensure_response($data);
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->header('X-KDA-Mode', 'read-only');
        return $response;
    }

    public function rest_agent() {
        return $this->no_store(KDA_Agent_Card::data());
    }

    public function rest_ping() {
        return $this->no_store(array(
            'ok' => true,
            'agent' => 'Kimiya Diagnostic Agent',
            'version' => KDA_VERSION,
            'time_utc' => gmdate('c'),
            'mode' => 'read-only',
        ));
    }

    public function rest_report() {
        $report = KDA_Diagnostics::full_report();
        $report['cache_layer'] = KDA_Cache_Inspector::inspect();
        return $this->no_store($report);
    }

    public function rest_profile() {
        return $this->no_store(array('meta' => array('agent_version' => KDA_VERSION, 'read_only' => true, 'generated_utc' => gmdate('c')), 'homepage_profile' => KDA_Profiler::run_home_profile()));
    }

    public function rest_repair_inspect() {
        return $this->no_store(KDA_Repair_Inspector::inspect());
    }

    public function rest_repair($request) {
        $action = sanitize_key((string)$request->get_param('action'));
        if ($action === 'jetmenu_performance') {
            $result = KDA_Repair::apply_jetmenu();
        } elseif ($action === 'rollback_jetmenu') {
            $result = KDA_Repair::rollback_jetmenu();
        } else {
            return new WP_Error('kda_repair_unknown', 'Unknown repair action.', array('status' => 400));
        }
        if (is_wp_error($result)) { return $result; }
        return $this->no_store($result);
    }

    public function rest_errors() {
        return $this->no_store(array(
            'fatal_errors' => KDA_Diagnostics::get_fatals(),
            'debug_log_tail' => KDA_Diagnostics::debug_log_tail(),
        ));
    }

    public function rest_update_status() {
        return $this->no_store(KDA_Updater::public_status());
    }

    public function rest_update_trigger() {
        $result = KDA_Updater::check_and_maybe_update(true);
        if (is_wp_error($result)) { return $result; }
        $response = rest_ensure_response(array(
            'ok' => true,
            'current_version' => KDA_VERSION,
            'result' => $result,
            'time_utc' => gmdate('c'),
        ));
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->header('X-KDA-Mode', 'signed-maintenance');
        return $response;
    }
}

register_activation_hook(__FILE__, array('Kimiya_Diagnostic_Agent', 'activate'));
register_deactivation_hook(__FILE__, array('Kimiya_Diagnostic_Agent', 'deactivate'));
Kimiya_Diagnostic_Agent::instance();
