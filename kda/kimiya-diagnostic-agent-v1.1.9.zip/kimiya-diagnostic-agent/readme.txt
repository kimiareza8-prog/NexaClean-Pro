=== Kimiya Diagnostic Agent ===
Contributors: kimiya
Tags: diagnostics, health, monitoring, signed-update
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.1.9
License: GPLv2 or later

Read-only remote diagnostics, deep network/WooCommerce health checks, and cryptographically signed self-updates with a signed remote update trigger.

== Installation ==
1. Upload the ZIP from Plugins > Add New > Upload Plugin.
2. Activate Kimiya Diagnostic Agent.
3. Open Tools > Kimiya Diagnostic Agent.
4. Create a temporary diagnostic link and share only that temporary URL/token.
5. Optionally install the Early Fatal Monitor from the same page.

== Diagnostic privacy ==
The agent does not expose passwords, wp-config.php, cookies, order/customer data, post content, user records, API keys or database credentials. Sensitive-looking strings are redacted. Debug-log output is limited to a tail and is redacted.

== Signed updates ==
Configure an HTTPS manifest URL. Each release manifest is verified with the embedded Ed25519 public key and each package is verified with SHA-256 before WordPress overwrites the current plugin.

Manifest fields:
version, package_url, sha256, min_wp, min_php, published_at, signature

Signature payload is exactly these six values joined by newline in this order:
version
package_url
sha256
min_wp
min_php
published_at

= 1.1.1 =
* Webhook/self-update verification release.
* No diagnostic write permissions added.

= 1.1.2 =
* Added one-time signed read-only diagnostic report endpoint for secure remote health checks.

= 1.1.3 =
* Added signed, read-only homepage profiler for WordPress phases, SQL timings, and outbound HTTP calls.

= 1.1.4 =
* Profiler now captures SQL timings and Elementor element render timings.

= 1.1.5 =
* Added signed read-only repair inspector for Elementor/JetMenu configuration discovery.

= 1.1.6 =
* Added limited signed JetMenu performance repair with automatic rollback backup.

= 1.1.7 =
* Added Tools > KDA Repair admin page with Apply and Rollback buttons.

= 1.1.8 =
* Added reversible Lazy Load optimization for the known slow JetEngine Listing Grid widgets on the homepage.

= 1.1.9 =
* Added token-authenticated /agent machine-readable usage guide so a new AI assistant can discover the read-only diagnostic workflow without prior chat context.
