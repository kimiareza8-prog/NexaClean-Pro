=== Kimiya Diagnostic Agent ===
Contributors: kimiya
Tags: diagnostics, health, monitoring, signed-update
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.1.1
License: GPLv2 or later

Read-only remote diagnostics, deep network/WooCommerce health checks, and cryptographically signed self-updates with a signed remote update trigger.

== Installation ==
1. Upload the ZIP from Plugins > Add New > Upload Plugin.
2. Activate Kimiya Diagnostic Agent.
3. Open Tools > Kimiya Diagnostic Agent.
4. Create a temporary diagnostic link and share only that temporary URL/token.
5. Optionally install the Early Fatal Monitor from the same page.

== Diagnostic privacy ==
The agent does not expose passwords, wp-config.php, cookies, order/customer data, post content, user records, API keys or database credentials. Sensitive-looking strings are redacted. Debug-log output is limited to a tail and is redacted.

== Signed updates ==
Configure an HTTPS manifest URL. Each release manifest is verified with the embedded Ed25519 public key and each package is verified with SHA-256 before WordPress overwrites the current plugin.

Manifest fields:
version, package_url, sha256, min_wp, min_php, published_at, signature

Signature payload is exactly these six values joined by newline in this order:
version
package_url
sha256
min_wp
min_php
published_at

= 1.1.1 =
* Webhook/self-update verification release.
* No diagnostic write permissions added.
