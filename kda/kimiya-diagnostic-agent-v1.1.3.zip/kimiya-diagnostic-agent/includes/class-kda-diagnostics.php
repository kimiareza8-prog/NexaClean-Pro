<?php
if (!defined('ABSPATH')) { exit; }

final class KDA_Diagnostics {
    const ERRORS_OPTION = 'kda_fatal_errors';

    public static function full_report() {
        global $wpdb;
        $started = microtime(true);

        $report = array(
            'meta' => array(
                'generated_utc' => gmdate('c'),
                'agent_version' => KDA_VERSION,
                'read_only' => true,
            ),
            'site' => self::site_info(),
            'runtime' => self::runtime_info(),
            'wordpress' => self::wordpress_info(),
            'plugins' => self::plugins_info(),
            'theme' => self::theme_info(),
            'database' => self::database_info($wpdb),
            'cron' => self::cron_info(),
            'filesystem' => self::filesystem_info(),
            'network' => self::network_info(),
            'dns_tls' => self::dns_tls_info(),
            'proxy' => self::proxy_info(),
            'woocommerce' => self::woocommerce_info($wpdb),
            'update' => class_exists('KDA_Updater') ? KDA_Updater::public_status() : array(),
            'errors' => array(
                'recent_fatals' => self::get_fatals(),
            ),
        );

        $report['meta']['collection_ms'] = round((microtime(true) - $started) * 1000, 1);
        return KDA_Security::redact($report);
    }

    private static function site_info() {
        $home = home_url('/');
        $site = site_url('/');
        return array(
            'home_url' => $home,
            'site_url' => $site,
            'https_home' => (stripos($home, 'https://') === 0),
            'https_site' => (stripos($site, 'https://') === 0),
            'multisite' => is_multisite(),
            'timezone' => wp_timezone_string(),
            'language' => get_locale(),
        );
    }

    private static function runtime_info() {
        $server = isset($_SERVER['SERVER_SOFTWARE']) ? sanitize_text_field(wp_unslash($_SERVER['SERVER_SOFTWARE'])) : 'unknown';
        return array(
            'php_version' => PHP_VERSION,
            'php_sapi' => PHP_SAPI,
            'server_software' => $server,
            'memory_limit' => ini_get('memory_limit'),
            'memory_usage_mb' => round(memory_get_usage(true) / 1048576, 2),
            'memory_peak_mb' => round(memory_get_peak_usage(true) / 1048576, 2),
            'max_execution_time' => ini_get('max_execution_time'),
            'max_input_vars' => ini_get('max_input_vars'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size'),
            'opcache_loaded' => extension_loaded('Zend OPcache'),
            'curl_loaded' => extension_loaded('curl'),
            'sodium_loaded' => extension_loaded('sodium'),
            'zip_loaded' => extension_loaded('zip'),
        );
    }

    private static function wordpress_info() {
        global $wp_version;
        $rules = get_option('rewrite_rules');
        return array(
            'version' => $wp_version,
            'debug' => defined('WP_DEBUG') ? (bool)WP_DEBUG : false,
            'debug_log' => defined('WP_DEBUG_LOG') ? (bool)WP_DEBUG_LOG : false,
            'debug_display' => defined('WP_DEBUG_DISPLAY') ? (bool)WP_DEBUG_DISPLAY : false,
            'cache' => defined('WP_CACHE') ? (bool)WP_CACHE : false,
            'object_cache_external' => function_exists('wp_using_ext_object_cache') ? (bool)wp_using_ext_object_cache() : false,
            'disallow_file_edit' => defined('DISALLOW_FILE_EDIT') ? (bool)DISALLOW_FILE_EDIT : false,
            'disallow_file_mods' => defined('DISALLOW_FILE_MODS') ? (bool)DISALLOW_FILE_MODS : false,
            'automatic_updater_disabled' => defined('AUTOMATIC_UPDATER_DISABLED') ? (bool)AUTOMATIC_UPDATER_DISABLED : false,
            'rewrite_rules_count' => is_array($rules) ? count($rules) : 0,
        );
    }

    private static function plugins_info() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all = get_plugins();
        $active = (array)get_option('active_plugins', array());
        $result = array();
        foreach ($all as $file => $data) {
            $result[] = array(
                'slug' => dirname($file) === '.' ? basename($file, '.php') : dirname($file),
                'name' => isset($data['Name']) ? $data['Name'] : $file,
                'version' => isset($data['Version']) ? $data['Version'] : '',
                'active' => in_array($file, $active, true) || (is_multisite() && is_plugin_active_for_network($file)),
                'network_only' => !empty($data['Network']),
            );
        }
        usort($result, function($a, $b) { return strcasecmp($a['name'], $b['name']); });
        return $result;
    }

    private static function theme_info() {
        $theme = wp_get_theme();
        return array(
            'name' => $theme->get('Name'),
            'version' => $theme->get('Version'),
            'template' => $theme->get_template(),
            'stylesheet' => $theme->get_stylesheet(),
            'is_child_theme' => is_child_theme(),
        );
    }

    private static function database_info($wpdb) {
        $start = microtime(true);
        $ok = $wpdb->get_var('SELECT 1'); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $latency = round((microtime(true) - $start) * 1000, 1);
        $autoload_bytes = null;
        $autoload_error = null;
        $prefix = $wpdb->esc_like($wpdb->options);
        try {
            $autoload_bytes = $wpdb->get_var("SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload IN ('yes','on','auto','auto-on')"); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        } catch (Throwable $e) {
            $autoload_error = $e->getMessage();
        }
        return array(
            'engine_version' => $wpdb->db_version(),
            'select_1_ok' => ((string)$ok === '1'),
            'select_1_latency_ms' => $latency,
            'last_error' => $wpdb->last_error ? KDA_Security::redact($wpdb->last_error) : '',
            'autoload_bytes' => is_numeric($autoload_bytes) ? (int)$autoload_bytes : null,
            'autoload_mb' => is_numeric($autoload_bytes) ? round(((int)$autoload_bytes) / 1048576, 2) : null,
            'autoload_query_error' => $autoload_error ? KDA_Security::redact($autoload_error) : null,
            'charset' => $wpdb->charset,
            'collate' => $wpdb->collate,
        );
    }

    private static function cron_info() {
        $crons = _get_cron_array();
        $now = time();
        $events = 0;
        $overdue = 0;
        $oldest = null;
        $overdue_hooks = array();
        if (is_array($crons)) {
            foreach ($crons as $ts => $hooks) {
                foreach ((array)$hooks as $hook => $instances) {
                    foreach ((array)$instances as $instance) {
                        $events++;
                        if ((int)$ts < ($now - 60)) {
                            $overdue++;
                            $overdue_hooks[$hook] = isset($overdue_hooks[$hook]) ? $overdue_hooks[$hook] + 1 : 1;
                            if ($oldest === null || (int)$ts < $oldest) { $oldest = (int)$ts; }
                        }
                    }
                }
            }
        }
        arsort($overdue_hooks);
        $top = array();
        foreach (array_slice($overdue_hooks, 0, 10, true) as $hook => $count) {
            $top[] = array('hook' => $hook, 'count' => $count);
        }
        return array(
            'disabled' => defined('DISABLE_WP_CRON') ? (bool)DISABLE_WP_CRON : false,
            'events_total' => $events,
            'overdue_events' => $overdue,
            'oldest_overdue_utc' => $oldest ? gmdate('c', $oldest) : null,
            'top_overdue_hooks' => $top,
            'spawn_cron_url' => site_url('wp-cron.php?doing_wp_cron=1'),
        );
    }

    private static function filesystem_info() {
        $free = @disk_free_space(ABSPATH);
        $total = @disk_total_space(ABSPATH);
        return array(
            'abspath_writable' => is_writable(ABSPATH),
            'wp_content_writable' => is_writable(WP_CONTENT_DIR),
            'plugins_dir_writable' => is_writable(WP_PLUGIN_DIR),
            'free_bytes' => is_numeric($free) ? (int)$free : null,
            'free_gb' => is_numeric($free) ? round($free / 1073741824, 2) : null,
            'total_gb' => is_numeric($total) ? round($total / 1073741824, 2) : null,
        );
    }

    private static function network_info() {
        $tests = array();
        $targets = array(
            'rest' => rest_url(''),
            'home' => home_url('/'),
        );
        foreach ($targets as $name => $url) {
            $start = microtime(true);
            $r = wp_safe_remote_head($url, array(
                'timeout' => 7,
                'redirection' => 3,
                'sslverify' => true,
                'user-agent' => 'Kimiya-Diagnostic-Agent/' . KDA_VERSION,
            ));
            $ms = round((microtime(true) - $start) * 1000, 1);
            if (is_wp_error($r)) {
                $tests[$name] = array('ok' => false, 'latency_ms' => $ms, 'error' => $r->get_error_message());
            } else {
                $tests[$name] = array(
                    'ok' => true,
                    'latency_ms' => $ms,
                    'http_code' => (int)wp_remote_retrieve_response_code($r),
                    'server' => (string)wp_remote_retrieve_header($r, 'server'),
                    'location' => (string)wp_remote_retrieve_header($r, 'location'),
                    'via' => (string)wp_remote_retrieve_header($r, 'via'),
                    'x_cache' => (string)wp_remote_retrieve_header($r, 'x-cache'),
                );
            }
        }

        $home = home_url('/');
        $parts = wp_parse_url($home);
        $host = isset($parts['host']) ? strtolower($parts['host']) : '';
        $scheme = isset($parts['scheme']) ? $parts['scheme'] : 'https';
        if ($host) {
            $root = preg_replace('/^www\./i', '', $host);
            $www = 'www.' . $root;
            $ip_any = defined('CURL_IPRESOLVE_WHATEVER') ? CURL_IPRESOLVE_WHATEVER : 0;
            $ip_v4 = defined('CURL_IPRESOLVE_V4') ? CURL_IPRESOLVE_V4 : 1;
            $ip_v6 = defined('CURL_IPRESOLVE_V6') ? CURL_IPRESOLVE_V6 : 2;
            $tests['frontend_variants'] = array(
                'root' => self::curl_probe($scheme . '://' . $root . '/', $ip_any),
                'www' => self::curl_probe($scheme . '://' . $www . '/', $ip_any),
                'www_ipv4' => self::curl_probe($scheme . '://' . $www . '/', $ip_v4),
                'www_ipv6' => self::curl_probe($scheme . '://' . $www . '/', $ip_v6),
            );
        }
        return $tests;
    }

    private static function curl_probe($url, $ipresolve) {
        if (!function_exists('curl_init')) { return array('available' => false, 'reason' => 'curl extension unavailable'); }
        $ch = curl_init();
        $opts = array(
            CURLOPT_URL => $url,
            CURLOPT_NOBODY => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'Kimiya-Diagnostic-Agent/' . KDA_VERSION,
            CURLOPT_IPRESOLVE => $ipresolve,
        );
        curl_setopt_array($ch, $opts);
        curl_exec($ch);
        $err_no = curl_errno($ch);
        $err = curl_error($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        return array(
            'ok' => $err_no === 0,
            'curl_errno' => $err_no,
            'error' => $err_no ? $err : '',
            'http_code' => isset($info['http_code']) ? (int)$info['http_code'] : 0,
            'primary_ip' => isset($info['primary_ip']) ? $info['primary_ip'] : '',
            'namelookup_ms' => isset($info['namelookup_time']) ? round($info['namelookup_time'] * 1000, 1) : null,
            'connect_ms' => isset($info['connect_time']) ? round($info['connect_time'] * 1000, 1) : null,
            'tls_ms' => isset($info['appconnect_time']) ? round($info['appconnect_time'] * 1000, 1) : null,
            'starttransfer_ms' => isset($info['starttransfer_time']) ? round($info['starttransfer_time'] * 1000, 1) : null,
            'total_ms' => isset($info['total_time']) ? round($info['total_time'] * 1000, 1) : null,
            'redirect_url' => isset($info['redirect_url']) ? $info['redirect_url'] : '',
        );
    }

    private static function dns_tls_info() {
        $parts = wp_parse_url(home_url('/'));
        $host = isset($parts['host']) ? strtolower($parts['host']) : '';
        if (!$host) { return array('available' => false); }
        $root = preg_replace('/^www\./i', '', $host);
        $hosts = array_values(array_unique(array($root, 'www.' . $root)));
        $out = array('available' => true, 'hosts' => array());
        foreach ($hosts as $h) {
            $item = array('host' => $h, 'a_records' => array(), 'aaaa_records' => array(), 'cname' => array());
            if (function_exists('dns_get_record')) {
                $dns_type = (defined('DNS_A') ? DNS_A : 1) | (defined('DNS_AAAA') ? DNS_AAAA : 134217728) | (defined('DNS_CNAME') ? DNS_CNAME : 16);
                $records = @dns_get_record($h, $dns_type);
                if (is_array($records)) {
                    foreach ($records as $r) {
                        $type = isset($r['type']) ? $r['type'] : '';
                        if ($type === 'A' && !empty($r['ip'])) { $item['a_records'][] = $r['ip']; }
                        if ($type === 'AAAA' && !empty($r['ipv6'])) { $item['aaaa_records'][] = $r['ipv6']; }
                        if ($type === 'CNAME' && !empty($r['target'])) { $item['cname'][] = $r['target']; }
                    }
                }
            } else {
                $ips = @gethostbynamel($h);
                if (is_array($ips)) { $item['a_records'] = $ips; }
            }
            $item['a_records'] = array_values(array_unique($item['a_records']));
            $item['aaaa_records'] = array_values(array_unique($item['aaaa_records']));
            $item['cname'] = array_values(array_unique($item['cname']));
            $item['tls'] = self::tls_probe($h);
            $out['hosts'][$h] = $item;
        }
        return $out;
    }

    private static function tls_probe($host) {
        if (!function_exists('stream_socket_client') || !function_exists('openssl_x509_parse')) {
            return array('available' => false);
        }
        $ctx = stream_context_create(array('ssl' => array(
            'capture_peer_cert' => true,
            'verify_peer' => true,
            'verify_peer_name' => true,
            'peer_name' => $host,
            'SNI_enabled' => true,
        )));
        $errno = 0; $errstr = '';
        $start = microtime(true);
        $fp = @stream_socket_client('ssl://' . $host . ':443', $errno, $errstr, 6, STREAM_CLIENT_CONNECT, $ctx);
        $elapsed = round((microtime(true) - $start) * 1000, 1);
        if (!$fp) { return array('available' => true, 'ok' => false, 'connect_ms' => $elapsed, 'errno' => $errno, 'error' => $errstr); }
        $params = stream_context_get_params($fp);
        fclose($fp);
        $cert = isset($params['options']['ssl']['peer_certificate']) ? $params['options']['ssl']['peer_certificate'] : null;
        $parsed = $cert ? @openssl_x509_parse($cert) : false;
        if (!$parsed) { return array('available' => true, 'ok' => true, 'connect_ms' => $elapsed, 'certificate_parsed' => false); }
        $valid_to = isset($parsed['validTo_time_t']) ? (int)$parsed['validTo_time_t'] : 0;
        return array(
            'available' => true,
            'ok' => true,
            'connect_ms' => $elapsed,
            'subject_cn' => isset($parsed['subject']['CN']) ? $parsed['subject']['CN'] : '',
            'issuer_cn' => isset($parsed['issuer']['CN']) ? $parsed['issuer']['CN'] : '',
            'valid_from_utc' => !empty($parsed['validFrom_time_t']) ? gmdate('c', (int)$parsed['validFrom_time_t']) : null,
            'valid_to_utc' => $valid_to ? gmdate('c', $valid_to) : null,
            'days_remaining' => $valid_to ? floor(($valid_to - time()) / DAY_IN_SECONDS) : null,
        );
    }

    private static function proxy_info() {
        $keys = array('SERVER_SOFTWARE','SERVER_PROTOCOL','HTTP_HOST','HTTP_X_FORWARDED_HOST','HTTP_X_FORWARDED_PROTO','HTTP_VIA','HTTP_CF_RAY','HTTP_X_CACHE','SERVER_ADDR');
        $out = array();
        foreach ($keys as $k) {
            if (isset($_SERVER[$k]) && is_scalar($_SERVER[$k])) {
                $out[strtolower($k)] = sanitize_text_field(wp_unslash((string)$_SERVER[$k]));
            }
        }
        return $out;
    }

    private static function woocommerce_info($wpdb) {
        $active = defined('WC_VERSION') || class_exists('WooCommerce');
        $out = array(
            'active' => $active,
            'version' => defined('WC_VERSION') ? WC_VERSION : null,
            'action_scheduler_version' => defined('ACTION_SCHEDULER_VERSION') ? ACTION_SCHEDULER_VERSION : null,
        );
        if (!$active) { return $out; }
        $table = $wpdb->prefix . 'actionscheduler_actions';
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if ($exists !== $table) {
            $out['action_scheduler_table'] = 'not_found';
            return $out;
        }
        $out['action_scheduler_table'] = 'available';
        $rows = $wpdb->get_results("SELECT status, COUNT(*) AS cnt FROM {$table} GROUP BY status", ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $counts = array();
        foreach ((array)$rows as $row) { $counts[$row['status']] = (int)$row['cnt']; }
        $out['actions_by_status'] = $counts;
        $oldest = $wpdb->get_row("SELECT hook, status, scheduled_date_gmt FROM {$table} WHERE status IN ('pending','in-progress') ORDER BY scheduled_date_gmt ASC LIMIT 1", ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $out['oldest_pending_or_running'] = $oldest ?: null;
        $top = $wpdb->get_results("SELECT hook, status, COUNT(*) AS cnt FROM {$table} WHERE status IN ('pending','failed','in-progress') GROUP BY hook, status ORDER BY cnt DESC LIMIT 12", ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $out['top_action_hooks'] = array_map(function($r){ return array('hook'=>$r['hook'],'status'=>$r['status'],'count'=>(int)$r['cnt']); }, (array)$top);
        return $out;
    }

    public static function store_fatal($error) {
        if (!is_array($error)) { return; }
        $settings = get_option('kda_settings', array());
        $keep = isset($settings['retain_errors']) ? max(5, min(100, (int)$settings['retain_errors'])) : 30;
        $items = (array)get_option(self::ERRORS_OPTION, array());
        $items[] = array(
            'time_utc' => gmdate('c'),
            'type' => isset($error['type']) ? (int)$error['type'] : 0,
            'message' => isset($error['message']) ? KDA_Security::redact((string)$error['message']) : '',
            'file' => isset($error['file']) ? self::safe_relative_path((string)$error['file']) : '',
            'line' => isset($error['line']) ? (int)$error['line'] : 0,
        );
        if (count($items) > $keep) { $items = array_slice($items, -$keep); }
        update_option(self::ERRORS_OPTION, $items, false);
    }

    private static function safe_relative_path($path) {
        $norm = wp_normalize_path($path);
        $base = wp_normalize_path(ABSPATH);
        if (strpos($norm, $base) === 0) {
            return '[ABSPATH]/' . ltrim(substr($norm, strlen($base)), '/');
        }
        return basename($norm);
    }

    public static function get_fatals() {
        return (array)get_option(self::ERRORS_OPTION, array());
    }

    public static function clear_fatals() {
        delete_option(self::ERRORS_OPTION);
    }

    public static function debug_log_tail() {
        $path = null;
        if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
            if (is_string(WP_DEBUG_LOG)) {
                $candidate = WP_DEBUG_LOG;
                if (!preg_match('#^([A-Za-z]:[\\\\/]|/)#', $candidate)) {
                    $candidate = WP_CONTENT_DIR . '/' . ltrim($candidate, '/\\');
                }
                $path = $candidate;
            } else {
                $path = WP_CONTENT_DIR . '/debug.log';
            }
        }
        if (!$path || !is_readable($path)) {
            return array('available' => false, 'lines' => array());
        }
        $real = realpath($path);
        $content_real = realpath(WP_CONTENT_DIR);
        if (!$real || !$content_real || strpos(wp_normalize_path($real), trailingslashit(wp_normalize_path($content_real))) !== 0) {
            return array('available' => false, 'reason' => 'Log path is outside wp-content.', 'lines' => array());
        }
        $size = filesize($real);
        $max = 131072;
        $offset = max(0, $size - $max);
        $fh = fopen($real, 'rb');
        if (!$fh) { return array('available' => false, 'lines' => array()); }
        if ($offset > 0) { fseek($fh, $offset); }
        $data = stream_get_contents($fh, $max);
        fclose($fh);
        $lines = preg_split('/\r\n|\r|\n/', (string)$data);
        $lines = array_slice(array_filter($lines, 'strlen'), -80);
        $lines = array_map(array('KDA_Security', 'redact'), $lines);
        return array('available' => true, 'lines' => array_values($lines));
    }
}
