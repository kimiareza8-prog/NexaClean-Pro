<?php
if (!defined('ABSPATH')) { exit; }

final class KDA_Security {
    const OPTION = 'kda_diag_session';

    public static function create_session($minutes = 30) {
        $minutes = max(5, min(1440, (int)$minutes));
        $token = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
        $record = array(
            'hash' => hash('sha256', $token),
            'created' => time(),
            'expires' => time() + ($minutes * MINUTE_IN_SECONDS),
            'requests' => 0,
            'window_started' => time(),
        );
        update_option(self::OPTION, $record, false);
        return $token;
    }

    public static function revoke_session() {
        delete_option(self::OPTION);
    }

    public static function session_info() {
        $r = get_option(self::OPTION, array());
        if (!$r || empty($r['expires'])) {
            return array('active' => false);
        }
        if ((int)$r['expires'] < time()) {
            self::revoke_session();
            return array('active' => false);
        }
        return array(
            'active' => true,
            'created' => (int)$r['created'],
            'expires' => (int)$r['expires'],
            'requests' => isset($r['requests']) ? (int)$r['requests'] : 0,
        );
    }

    private static function request_token($request) {
        $auth = $request->get_header('authorization');
        if ($auth && preg_match('/^Bearer\s+(.+)$/i', trim($auth), $m)) {
            return trim($m[1]);
        }
        $token = $request->get_param('kda_token');
        return is_string($token) ? trim($token) : '';
    }

    public static function authorize_diagnostic_request($request) {
        $record = get_option(self::OPTION, array());
        if (!$record || empty($record['hash']) || empty($record['expires'])) {
            return new WP_Error('kda_no_session', 'No active diagnostic session.', array('status' => 401));
        }
        if ((int)$record['expires'] < time()) {
            self::revoke_session();
            return new WP_Error('kda_session_expired', 'Diagnostic session expired.', array('status' => 401));
        }

        $token = self::request_token($request);
        if (!$token || !hash_equals($record['hash'], hash('sha256', $token))) {
            return new WP_Error('kda_invalid_token', 'Invalid diagnostic token.', array('status' => 403));
        }

        $now = time();
        $window = isset($record['window_started']) ? (int)$record['window_started'] : $now;
        $requests = isset($record['requests']) ? (int)$record['requests'] : 0;
        if (($now - $window) >= HOUR_IN_SECONDS) {
            $window = $now;
            $requests = 0;
        }
        if ($requests >= 120) {
            return new WP_Error('kda_rate_limited', 'Diagnostic request limit reached.', array('status' => 429));
        }
        $record['window_started'] = $window;
        $record['requests'] = $requests + 1;
        update_option(self::OPTION, $record, false);
        return true;
    }

    private static function decode_b64url($value) {
        $value = strtr(trim((string)$value), '-_', '+/');
        $pad = strlen($value) % 4;
        if ($pad) { $value .= str_repeat('=', 4 - $pad); }
        return base64_decode($value, true);
    }

    public static function authorize_signed_report_request($request) {
        if (!function_exists('sodium_crypto_sign_verify_detached')) {
            return new WP_Error('kda_no_sodium', 'PHP Sodium extension is required.', array('status' => 503));
        }
        $ts = (int)$request->get_param('ts');
        $nonce = trim((string)$request->get_param('nonce'));
        $sig_text = trim((string)$request->get_param('sig'));
        if (!$ts || abs(time() - $ts) > 600 || !preg_match('/^[A-Za-z0-9_-]{20,128}$/', $nonce) || !$sig_text) {
            return new WP_Error('kda_signed_report_invalid', 'Invalid or expired signed report request.', array('status' => 403));
        }
        $nonce_key = 'kda_signed_report_nonce_' . substr(hash('sha256', $nonce), 0, 32);
        if (get_transient($nonce_key)) {
            return new WP_Error('kda_signed_report_replay', 'Signed report request was already used.', array('status' => 409));
        }
        $pub = base64_decode((string)get_option('kda_update_public_key', KDA_DEFAULT_PUBLIC_KEY), true);
        $sig = self::decode_b64url($sig_text);
        if ($pub === false || strlen($pub) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || $sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) {
            return new WP_Error('kda_signed_report_signature_format', 'Invalid signature format.', array('status' => 403));
        }
        $payload = "report\n" . $ts . "\n" . $nonce;
        if (!sodium_crypto_sign_verify_detached($sig, $payload, $pub)) {
            return new WP_Error('kda_signed_report_signature', 'Invalid signed report signature.', array('status' => 403));
        }
        set_transient($nonce_key, 1, 15 * MINUTE_IN_SECONDS);
        return true;
    }

    public static function authorize_signed_profile_request($request) {
        if (!function_exists('sodium_crypto_sign_verify_detached')) {
            return new WP_Error('kda_no_sodium', 'PHP Sodium extension is required.', array('status' => 503));
        }
        $ts = (int)$request->get_param('ts');
        $nonce = trim((string)$request->get_param('nonce'));
        $sig_text = trim((string)$request->get_param('sig'));
        if (!$ts || abs(time() - $ts) > 600 || !preg_match('/^[A-Za-z0-9_-]{20,128}$/', $nonce) || !$sig_text) {
            return new WP_Error('kda_signed_profile_invalid', 'Invalid or expired signed profile request.', array('status' => 403));
        }
        $nonce_key = 'kda_signed_profile_nonce_' . substr(hash('sha256', $nonce), 0, 32);
        if (get_transient($nonce_key)) {
            return new WP_Error('kda_signed_profile_replay', 'Signed profile request was already used.', array('status' => 409));
        }
        $pub = base64_decode((string)get_option('kda_update_public_key', KDA_DEFAULT_PUBLIC_KEY), true);
        $sig = self::decode_b64url($sig_text);
        if ($pub === false || strlen($pub) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || $sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) {
            return new WP_Error('kda_signed_profile_signature_format', 'Invalid signature format.', array('status' => 403));
        }
        $payload = "profile
" . $ts . "
" . $nonce;
        if (!sodium_crypto_sign_verify_detached($sig, $payload, $pub)) {
            return new WP_Error('kda_signed_profile_signature', 'Invalid signed profile signature.', array('status' => 403));
        }
        set_transient($nonce_key, 1, 15 * MINUTE_IN_SECONDS);
        return true;
    }

    public static function authorize_signed_update_trigger($request) {
        if (!function_exists('sodium_crypto_sign_verify_detached')) {
            return new WP_Error('kda_no_sodium', 'PHP Sodium extension is required.', array('status' => 503));
        }
        if (get_transient('kda_webhook_rate_lock')) {
            return new WP_Error('kda_webhook_rate', 'Update trigger is rate limited.', array('status' => 429));
        }
        $ts = (int)$request->get_param('ts');
        $nonce = trim((string)$request->get_param('nonce'));
        $sig_text = trim((string)$request->get_param('sig'));
        if (!$ts || abs(time() - $ts) > 900 || !preg_match('/^[A-Za-z0-9_-]{20,128}$/', $nonce) || !$sig_text) {
            return new WP_Error('kda_webhook_invalid', 'Invalid or expired signed update trigger.', array('status' => 403));
        }
        $nonce_key = 'kda_webhook_nonce_' . substr(hash('sha256', $nonce), 0, 32);
        if (get_transient($nonce_key)) {
            return new WP_Error('kda_webhook_replay', 'Signed update trigger was already used.', array('status' => 409));
        }
        $pub = base64_decode((string)get_option('kda_update_public_key', KDA_DEFAULT_PUBLIC_KEY), true);
        $sig = self::decode_b64url($sig_text);
        if ($pub === false || strlen($pub) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || $sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) {
            return new WP_Error('kda_webhook_signature_format', 'Invalid signature format.', array('status' => 403));
        }
        $payload = "update\n" . $ts . "\n" . $nonce;
        if (!sodium_crypto_sign_verify_detached($sig, $payload, $pub)) {
            return new WP_Error('kda_webhook_signature', 'Invalid update trigger signature.', array('status' => 403));
        }
        set_transient($nonce_key, 1, DAY_IN_SECONDS);
        set_transient('kda_webhook_rate_lock', 1, 30);
        return true;
    }

    public static function redact($value) {
        if (is_array($value)) {
            foreach ($value as $k => $v) {
                $key = strtolower((string)$k);
                if (preg_match('/pass|secret|token|cookie|authorization|api[_-]?key|nonce|salt/', $key)) {
                    $value[$k] = '[REDACTED]';
                } elseif (in_array($key, array('a_records','aaaa_records','primary_ip','server_addr'), true)) {
                    $value[$k] = $v;
                } else {
                    $value[$k] = self::redact($v);
                }
            }
            return $value;
        }
        if (!is_string($value)) { return $value; }

        $s = $value;
        $s = preg_replace('/[A-Z]:\\\\[^\r\n\t ]+/i', '[PATH]', $s);
        if (defined('ABSPATH') && ABSPATH) {
            $s = str_replace(wp_normalize_path(ABSPATH), '[ABSPATH]/', wp_normalize_path($s));
        }
        $s = preg_replace('/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i', '[EMAIL]', $s);
        $s = preg_replace('/\b(?:\d{1,3}\.){3}\d{1,3}\b/', '[IP]', $s);
        $s = preg_replace('/([?&](?:token|key|secret|password|pass|auth)=)[^&\s]+/i', '$1[REDACTED]', $s);
        return $s;
    }
}
