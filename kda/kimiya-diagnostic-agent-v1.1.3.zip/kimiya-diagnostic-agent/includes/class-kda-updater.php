<?php
if (!defined('ABSPATH')) { exit; }

final class KDA_Updater {
    const STATUS_OPTION = 'kda_update_status';

    public static function maybe_migrate_settings() {
        if (get_option('kda_release_channel_bootstrapped')) { return; }
        $settings = (array)get_option('kda_settings', array());
        if (empty($settings['manifest_url']) && defined('KDA_DEFAULT_MANIFEST_URL')) {
            $settings['manifest_url'] = KDA_DEFAULT_MANIFEST_URL;
        }
        // v1.1 enables the signed release channel requested by the site owner.
        $settings['auto_update'] = 1;
        if (!isset($settings['retain_errors'])) { $settings['retain_errors'] = 30; }
        update_option('kda_settings', $settings, false);
        update_option('kda_release_channel_bootstrapped', 1, false);
    }

    public static function settings() {
        $defaults = array('manifest_url' => '', 'auto_update' => 0, 'retain_errors' => 30);
        return wp_parse_args((array)get_option('kda_settings', array()), $defaults);
    }

    public static function public_status() {
        $settings = self::settings();
        $status = (array)get_option(self::STATUS_OPTION, array());
        return array(
            'current_version' => KDA_VERSION,
            'manifest_configured' => !empty($settings['manifest_url']),
            'auto_update' => !empty($settings['auto_update']),
            'signature_method' => 'Ed25519',
            'sodium_available' => function_exists('sodium_crypto_sign_verify_detached'),
            'last_check' => isset($status['last_check']) ? $status['last_check'] : null,
            'last_result' => isset($status['last_result']) ? $status['last_result'] : null,
            'available_version' => isset($status['available_version']) ? $status['available_version'] : null,
        );
    }

    private static function save_status($result, $extra = array()) {
        $status = array_merge(array(
            'last_check' => gmdate('c'),
            'last_result' => sanitize_text_field((string)$result),
        ), $extra);
        update_option(self::STATUS_OPTION, $status, false);
    }

    private static function canonical_payload($m) {
        $fields = array('version','package_url','sha256','min_wp','min_php','published_at');
        $parts = array();
        foreach ($fields as $f) { $parts[] = isset($m[$f]) ? trim((string)$m[$f]) : ''; }
        return implode("\n", $parts);
    }

    public static function check_manifest() {
        $settings = self::settings();
        $url = trim((string)$settings['manifest_url']);
        if (!$url) {
            return new WP_Error('kda_no_manifest', 'No update manifest URL configured.');
        }
        if (stripos($url, 'https://') !== 0) {
            return new WP_Error('kda_manifest_https', 'Manifest URL must use HTTPS.');
        }
        if (!function_exists('sodium_crypto_sign_verify_detached')) {
            return new WP_Error('kda_no_sodium', 'PHP Sodium extension is required for signed updates.');
        }

        $response = wp_safe_remote_get($url, array(
            'timeout' => 12,
            'redirection' => 3,
            'sslverify' => true,
            'headers' => array('Accept' => 'application/json'),
            'user-agent' => 'Kimiya-Diagnostic-Agent/' . KDA_VERSION,
        ));
        if (is_wp_error($response)) {
            self::save_status('manifest_fetch_failed');
            return $response;
        }
        $code = (int)wp_remote_retrieve_response_code($response);
        $body = (string)wp_remote_retrieve_body($response);
        if ($code !== 200 || strlen($body) > 131072) {
            self::save_status('manifest_http_error');
            return new WP_Error('kda_manifest_http', 'Manifest request failed or response was too large.');
        }
        $m = json_decode($body, true);
        if (!is_array($m)) {
            self::save_status('manifest_invalid_json');
            return new WP_Error('kda_manifest_json', 'Manifest is not valid JSON.');
        }
        foreach (array('version','package_url','sha256','min_wp','min_php','published_at','signature') as $key) {
            if (empty($m[$key])) {
                return new WP_Error('kda_manifest_missing', 'Manifest is missing required field: ' . $key);
            }
        }
        if (stripos($m['package_url'], 'https://') !== 0) {
            return new WP_Error('kda_package_https', 'Package URL must use HTTPS.');
        }
        if (!preg_match('/^[a-f0-9]{64}$/i', $m['sha256'])) {
            return new WP_Error('kda_hash_invalid', 'Manifest SHA-256 is invalid.');
        }

        $pub = base64_decode((string)get_option('kda_update_public_key', KDA_DEFAULT_PUBLIC_KEY), true);
        $sig = base64_decode((string)$m['signature'], true);
        if ($pub === false || strlen($pub) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || $sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) {
            return new WP_Error('kda_signature_format', 'Public key or signature has an invalid format.');
        }
        $valid = sodium_crypto_sign_verify_detached($sig, self::canonical_payload($m), $pub);
        if (!$valid) {
            self::save_status('signature_invalid');
            return new WP_Error('kda_signature_invalid', 'Update manifest signature is invalid.');
        }

        global $wp_version;
        if (version_compare(PHP_VERSION, (string)$m['min_php'], '<')) {
            return new WP_Error('kda_php_too_old', 'This update requires a newer PHP version.');
        }
        if (version_compare($wp_version, (string)$m['min_wp'], '<')) {
            return new WP_Error('kda_wp_too_old', 'This update requires a newer WordPress version.');
        }

        $available = version_compare((string)$m['version'], KDA_VERSION, '>');
        self::save_status($available ? 'update_available' : 'up_to_date', array(
            'available_version' => sanitize_text_field((string)$m['version']),
        ));
        return array('available' => $available, 'manifest' => $m);
    }

    private static function create_backup() {
        if (!class_exists('ZipArchive')) { return null; }
        $backup_dir = WP_CONTENT_DIR . '/kda-backups';
        if (!is_dir($backup_dir) && !wp_mkdir_p($backup_dir)) { return null; }
        @file_put_contents($backup_dir . '/index.php', "<?php\n// Silence is golden.\n");
        @file_put_contents($backup_dir . '/.htaccess', "Deny from all\n");
        $file = $backup_dir . '/kimiya-diagnostic-agent-' . KDA_VERSION . '-' . gmdate('Ymd-His') . '.zip';
        $zip = new ZipArchive();
        if ($zip->open($file, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) { return null; }
        $root = realpath(KDA_DIR);
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $entry) {
            if (!$entry->isFile()) { continue; }
            $path = $entry->getRealPath();
            $rel = 'kimiya-diagnostic-agent/' . ltrim(str_replace(wp_normalize_path($root), '', wp_normalize_path($path)), '/');
            $zip->addFile($path, $rel);
        }
        $zip->close();
        $files = glob($backup_dir . '/kimiya-diagnostic-agent-*.zip');
        if (is_array($files) && count($files) > 3) {
            usort($files, function($a, $b){ return filemtime($a) <=> filemtime($b); });
            while (count($files) > 3) { $old = array_shift($files); @unlink($old); }
        }
        return $file;
    }

    public static function apply_manifest($m) {
        if (get_transient('kda_update_lock')) {
            return new WP_Error('kda_update_locked', 'Another update operation is already running.');
        }
        set_transient('kda_update_lock', 1, 10 * MINUTE_IN_SECONDS);

        try {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
            require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

            $tmp = download_url((string)$m['package_url'], 60);
            if (is_wp_error($tmp)) { return $tmp; }
            $hash = hash_file('sha256', $tmp);
            if (!$hash || !hash_equals(strtolower((string)$m['sha256']), strtolower($hash))) {
                @unlink($tmp);
                return new WP_Error('kda_package_hash', 'Downloaded update package failed SHA-256 verification.');
            }

            self::create_backup();

            $skin = new Automatic_Upgrader_Skin();
            $upgrader = new Plugin_Upgrader($skin);
            $result = $upgrader->install($tmp, array(
                'clear_update_cache' => true,
                'overwrite_package' => true,
            ));
            @unlink($tmp);

            if (is_wp_error($result)) { return $result; }
            if (!$result) {
                return new WP_Error('kda_update_failed', 'WordPress upgrader did not complete the update.');
            }
            self::save_status('updated', array('available_version' => sanitize_text_field((string)$m['version'])));
            return true;
        } finally {
            delete_transient('kda_update_lock');
        }
    }

    public static function check_and_maybe_update($allow_apply = false) {
        $check = self::check_manifest();
        if (is_wp_error($check)) { return $check; }
        if (empty($check['available'])) { return array('updated' => false, 'reason' => 'up_to_date'); }
        if (!$allow_apply) { return array('updated' => false, 'reason' => 'update_available', 'version' => $check['manifest']['version']); }
        $result = self::apply_manifest($check['manifest']);
        if (is_wp_error($result)) { return $result; }
        return array('updated' => true, 'version' => $check['manifest']['version']);
    }

    public static function cron_run() {
        $settings = self::settings();
        if (empty($settings['auto_update']) || empty($settings['manifest_url'])) { return; }
        self::check_and_maybe_update(true);
    }
}
