<?php
if (!defined('ABSPATH')) { exit; }

final class KDA_Admin {
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_post_kda_create_session', array(__CLASS__, 'create_session'));
        add_action('admin_post_kda_revoke_session', array(__CLASS__, 'revoke_session'));
        add_action('admin_post_kda_save_settings', array(__CLASS__, 'save_settings'));
        add_action('admin_post_kda_check_update', array(__CLASS__, 'check_update'));
        add_action('admin_post_kda_apply_update', array(__CLASS__, 'apply_update'));
        add_action('admin_post_kda_clear_errors', array(__CLASS__, 'clear_errors'));
        add_action('admin_post_kda_install_mu', array(__CLASS__, 'install_mu'));
        add_action('admin_post_kda_remove_mu', array(__CLASS__, 'remove_mu'));
        add_action('admin_notices', array(__CLASS__, 'notices'));
    }

    public static function menu() {
        add_management_page('Kimiya Diagnostic Agent', 'Kimiya Diagnostic Agent', 'manage_options', 'kimiya-diagnostic-agent', array(__CLASS__, 'page'));
    }

    private static function guard($action) {
        if (!current_user_can('manage_options')) { wp_die('Unauthorized'); }
        check_admin_referer($action);
    }

    private static function redirect($msg, $type = 'success') {
        wp_safe_redirect(add_query_arg(array('page'=>'kimiya-diagnostic-agent','kda_msg'=>$msg,'kda_type'=>$type), admin_url('tools.php')));
        exit;
    }

    public static function notices() {
        if (empty($_GET['page']) || $_GET['page'] !== 'kimiya-diagnostic-agent' || empty($_GET['kda_msg'])) { return; }
        $type = (!empty($_GET['kda_type']) && $_GET['kda_type'] === 'error') ? 'error' : 'success';
        echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . esc_html(wp_unslash($_GET['kda_msg'])) . '</p></div>';
    }

    public static function create_session() {
        self::guard('kda_create_session');
        $minutes = isset($_POST['minutes']) ? (int)$_POST['minutes'] : 30;
        $token = KDA_Security::create_session($minutes);
        set_transient('kda_token_' . get_current_user_id(), $token, 5 * MINUTE_IN_SECONDS);
        self::redirect('Diagnostic session created. The token is shown once below.');
    }

    public static function revoke_session() {
        self::guard('kda_revoke_session');
        KDA_Security::revoke_session();
        self::redirect('Diagnostic session revoked.');
    }

    public static function save_settings() {
        self::guard('kda_save_settings');
        $manifest = isset($_POST['manifest_url']) ? esc_url_raw(trim(wp_unslash($_POST['manifest_url']))) : '';
        if ($manifest && stripos($manifest, 'https://') !== 0) {
            self::redirect('Manifest URL must use HTTPS.', 'error');
        }
        $retain = isset($_POST['retain_errors']) ? max(5, min(100, (int)$_POST['retain_errors'])) : 30;
        update_option('kda_settings', array(
            'manifest_url' => $manifest,
            'auto_update' => !empty($_POST['auto_update']) ? 1 : 0,
            'retain_errors' => $retain,
        ), false);
        self::redirect('Settings saved.');
    }

    public static function check_update() {
        self::guard('kda_check_update');
        $r = KDA_Updater::check_and_maybe_update(false);
        if (is_wp_error($r)) { self::redirect($r->get_error_message(), 'error'); }
        if (!empty($r['version'])) { self::redirect('Signed update available: ' . $r['version']); }
        self::redirect('The agent is up to date.');
    }

    public static function apply_update() {
        self::guard('kda_apply_update');
        $r = KDA_Updater::check_and_maybe_update(true);
        if (is_wp_error($r)) { self::redirect($r->get_error_message(), 'error'); }
        self::redirect(!empty($r['updated']) ? 'Signed update installed successfully.' : 'No update was required.');
    }

    public static function clear_errors() {
        self::guard('kda_clear_errors');
        KDA_Diagnostics::clear_fatals();
        self::redirect('Captured fatal errors cleared.');
    }

    private static function mu_target() {
        return WPMU_PLUGIN_DIR . '/kimiya-diagnostic-early-monitor.php';
    }

    public static function install_mu() {
        self::guard('kda_install_mu');
        if (!is_dir(WPMU_PLUGIN_DIR) && !wp_mkdir_p(WPMU_PLUGIN_DIR)) {
            self::redirect('Could not create mu-plugins directory.', 'error');
        }
        $src = KDA_DIR . 'mu/kimiya-diagnostic-early-monitor.php';
        if (!is_readable($src) || !@copy($src, self::mu_target())) {
            self::redirect('Could not install the early monitor. Check filesystem permissions.', 'error');
        }
        self::redirect('Early fatal monitor installed as a must-use plugin.');
    }

    public static function remove_mu() {
        self::guard('kda_remove_mu');
        $target = self::mu_target();
        if (file_exists($target) && !@unlink($target)) {
            self::redirect('Could not remove the early monitor.', 'error');
        }
        self::redirect('Early fatal monitor removed.');
    }

    public static function page() {
        if (!current_user_can('manage_options')) { return; }
        $session = KDA_Security::session_info();
        $settings = KDA_Updater::settings();
        $status = KDA_Updater::public_status();
        $token = get_transient('kda_token_' . get_current_user_id());
        if ($token) { delete_transient('kda_token_' . get_current_user_id()); }
        $mu_installed = file_exists(self::mu_target());
        $base = rest_url('kda/v1');
        ?>
        <div class="wrap">
            <h1>Kimiya Diagnostic Agent <small style="font-size:14px;color:#666">v<?php echo esc_html(KDA_VERSION); ?></small></h1>
            <p><strong>Diagnostic API is read-only.</strong> It cannot change posts, orders, users, settings, files, plugins, themes or the database. Self-update is a separate signed mechanism.</p>

            <?php if ($token): ?>
                <div class="notice notice-warning"><p><strong>One-time token — save/share it now:</strong></p>
                    <p><code style="user-select:all;word-break:break-all"><?php echo esc_html($token); ?></code></p>
                    <p>Report URL: <code style="user-select:all;word-break:break-all"><?php echo esc_html($base . '/report?kda_token=' . rawurlencode($token)); ?></code></p>
                </div>
            <?php endif; ?>

            <h2>1. Temporary diagnostic session</h2>
            <?php if (!empty($session['active'])): ?>
                <p>Status: <strong style="color:#0a7a20">ACTIVE</strong> — expires <?php echo esc_html(gmdate('Y-m-d H:i:s', $session['expires'])); ?> UTC.</p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="kda_revoke_session"><?php wp_nonce_field('kda_revoke_session'); ?>
                    <?php submit_button('Revoke diagnostic access', 'secondary', 'submit', false); ?>
                </form>
            <?php else: ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="kda_create_session"><?php wp_nonce_field('kda_create_session'); ?>
                    <label>Validity <select name="minutes"><option value="15">15 minutes</option><option value="30" selected>30 minutes</option><option value="60">1 hour</option><option value="360">6 hours</option><option value="1440">24 hours</option></select></label>
                    <?php submit_button('Create read-only diagnostic link', 'primary', 'submit', false); ?>
                </form>
            <?php endif; ?>
            <p>Endpoints: <code>/ping</code>, <code>/report</code>, <code>/errors</code>, <code>/update-status</code>. Signed maintenance webhook: <code>/update-trigger</code>. Token is accepted as <code>Authorization: Bearer</code> or <code>?kda_token=</code>.</p>

            <hr><h2>2. Early fatal monitor</h2>
            <p>This optional MU-plugin loads before normal plugins and can record fatal errors that happen too early for the normal agent to see.</p>
            <p>Status: <strong><?php echo $mu_installed ? 'Installed' : 'Not installed'; ?></strong></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;margin-right:8px">
                <input type="hidden" name="action" value="<?php echo $mu_installed ? 'kda_remove_mu' : 'kda_install_mu'; ?>">
                <?php wp_nonce_field($mu_installed ? 'kda_remove_mu' : 'kda_install_mu'); ?>
                <?php submit_button($mu_installed ? 'Remove early monitor' : 'Install early monitor', 'secondary', 'submit', false); ?>
            </form>

            <hr><h2>3. Signed self-update</h2>
            <p>Only a release whose manifest has a valid Ed25519 signature and whose ZIP matches the declared SHA-256 can replace this plugin. v1.1 also supports a one-time signed remote trigger that can only ask the agent to install such a verified release.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="kda_save_settings"><?php wp_nonce_field('kda_save_settings'); ?>
                <table class="form-table"><tbody>
                    <tr><th><label for="manifest_url">Manifest URL</label></th><td><input class="regular-text code" type="url" id="manifest_url" name="manifest_url" value="<?php echo esc_attr($settings['manifest_url']); ?>" placeholder="https://.../manifest.json"><p class="description">HTTPS only. A GitHub raw/release manifest is suitable.</p></td></tr>
                    <tr><th>Automatic signed updates</th><td><label><input type="checkbox" name="auto_update" value="1" <?php checked(!empty($settings['auto_update'])); ?>> Check hourly and install newer valid signed releases automatically.</label></td></tr>
                    <tr><th>Retain fatal errors</th><td><input type="number" min="5" max="100" name="retain_errors" value="<?php echo esc_attr((int)$settings['retain_errors']); ?>"></td></tr>
                    <tr><th>Embedded public key</th><td><code style="word-break:break-all"><?php echo esc_html(get_option('kda_update_public_key', KDA_DEFAULT_PUBLIC_KEY)); ?></code></td></tr>
                </tbody></table>
                <?php submit_button('Save settings'); ?>
            </form>
            <p>Last check: <code><?php echo esc_html($status['last_check'] ?: 'never'); ?></code> &nbsp; Result: <code><?php echo esc_html($status['last_result'] ?: 'none'); ?></code></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;margin-right:8px">
                <input type="hidden" name="action" value="kda_check_update"><?php wp_nonce_field('kda_check_update'); ?><?php submit_button('Check signed update', 'secondary', 'submit', false); ?>
            </form>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block">
                <input type="hidden" name="action" value="kda_apply_update"><?php wp_nonce_field('kda_apply_update'); ?><?php submit_button('Check and install signed update', 'primary', 'submit', false); ?>
            </form>

            <hr><h2>4. Captured errors</h2>
            <p>Stored fatal events: <strong><?php echo esc_html(count(KDA_Diagnostics::get_fatals())); ?></strong></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="kda_clear_errors"><?php wp_nonce_field('kda_clear_errors'); ?><?php submit_button('Clear captured errors', 'secondary', 'submit', false); ?>
            </form>

            <hr><h2>Safety model</h2>
            <ul style="list-style:disc;padding-left:22px">
                <li>No arbitrary remote write/execute endpoint exists. The signed maintenance webhook can only trigger the cryptographically verified self-updater.</li>
                <li>Diagnostic links expire and can be revoked immediately.</li>
                <li>Sensitive-looking values are redacted before diagnostic output.</li>
                <li>Update packages require HTTPS, Ed25519 signature verification, SHA-256 verification and WordPress' plugin upgrader.</li>
                <li>The updater keeps up to three local backups when ZipArchive is available.</li>
            </ul>
        </div>
        <?php
    }
}
