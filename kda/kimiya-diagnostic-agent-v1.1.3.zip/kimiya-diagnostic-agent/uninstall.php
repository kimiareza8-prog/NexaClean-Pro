<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
// Diagnostic data is removed on uninstall. The optional MU monitor is intentionally not deleted automatically.
delete_option('kda_diag_session');
delete_option('kda_settings');
delete_option('kda_update_status');
delete_option('kda_update_public_key');
delete_option('kda_fatal_errors');

delete_option('kda_release_channel_bootstrapped');
