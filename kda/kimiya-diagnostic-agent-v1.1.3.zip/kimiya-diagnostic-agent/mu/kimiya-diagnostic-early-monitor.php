<?php
/**
 * Plugin Name: Kimiya Diagnostic Early Monitor
 * Description: Minimal must-use fatal error recorder for Kimiya Diagnostic Agent.
 */
if (!defined('ABSPATH')) { exit; }

register_shutdown_function(function () {
    $e = error_get_last();
    if (!$e || !in_array((int)$e['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR), true)) { return; }

    $message = isset($e['message']) ? (string)$e['message'] : '';
    $message = preg_replace('/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i', '[EMAIL]', $message);
    $message = preg_replace('/\b(?:\d{1,3}\.){3}\d{1,3}\b/', '[IP]', $message);
    if (defined('ABSPATH')) { $message = str_replace(wp_normalize_path(ABSPATH), '[ABSPATH]/', wp_normalize_path($message)); }

    $file = isset($e['file']) ? wp_normalize_path((string)$e['file']) : '';
    if (defined('ABSPATH') && strpos($file, wp_normalize_path(ABSPATH)) === 0) {
        $file = '[ABSPATH]/' . ltrim(substr($file, strlen(wp_normalize_path(ABSPATH))), '/');
    } else {
        $file = basename($file);
    }

    $items = (array)get_option('kda_fatal_errors', array());
    $items[] = array(
        'time_utc' => gmdate('c'),
        'type' => isset($e['type']) ? (int)$e['type'] : 0,
        'message' => $message,
        'file' => $file,
        'line' => isset($e['line']) ? (int)$e['line'] : 0,
        'source' => 'mu-early-monitor',
    );
    if (count($items) > 30) { $items = array_slice($items, -30); }
    update_option('kda_fatal_errors', $items, false);
});
